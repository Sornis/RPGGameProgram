using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.Threading;

namespace RPGGameProgram
{
    // Class acts on the values in CharacterState
    class CharacterAction
    {

        CharacterState character;

        public CharacterAction(CharacterState character)
        {
            this.character = character;
        }

        public void Move(MoveIf mover)
        {
            if (!mover())
            {
                character.TrackXY();
                Canvas.SetLeft(character.rectangle, character.x);
                Canvas.SetTop(character.rectangle, character.y);
            }
        }

    }
        public delegate bool MoveIf();
}