using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.Threading;

namespace RPGGameProgram
{
    class CharacterState
    {
        public string characterType;
        public bool moveLeft, moveRight, moveUp, moveDown;
        public bool isSolid;
        public bool isPlayer;
        public double moveSpeed = 2;
        public double charWidth = 10;
        public double charHeight = 10;
        public double x, y;
        public int zIndex;
        public SolidColorBrush colour = Brushes.White;
        public Rectangle? rectangle;

        public CharacterState(int zIndex, bool isSolid, bool isPlayer)
        {
            this.zIndex = zIndex;
            this.isSolid = isSolid;
            this.isPlayer = isPlayer;

            if (this.isPlayer)
            {
                InitPos initPosition = new InitPos(InitPlayerPos);
                InitRect(initPosition);
            }
            else
            {

            }
        }

        public void InitPlayerPos()
        {
            x = 800 / 2 - MapState.mapWidth / 2 - charWidth / 2;
            y = 500 / 2 - MapState.mapHeight / 2 - charHeight / 2;
        }
        public void InitRect(InitPos initPos)
        {
            initPos();
            rectangle = new Rectangle();
            rectangle.Height = charHeight;
            rectangle.Width = charWidth;
            rectangle.Fill = colour;
            Canvas.SetLeft(rectangle, x);
            Canvas.SetTop(rectangle, y);
            Panel.SetZIndex(rectangle, zIndex);
        }

        public bool AtOuterBounds()
        {
            return x > MapState.mapXLocation + MapState.mapWidth - charWidth || x < MapState.mapXLocation || y > MapState.mapHeight + MapState.mapYLocation - charHeight || y < MapState.mapYLocation;
        }

        public void TrackXY()
        {
            if (moveUp)
            {
                y = y - moveSpeed;
            }
            if (moveDown)
            {
                y = y + moveSpeed;
            }
            if (moveLeft)
            {
                x = x - moveSpeed;
            }
            if (moveRight)
            {
                x = x + moveSpeed;
            }
        }
        public int[] GetClosestTile()
        {
            int[] tileValuesY = new int[MapState.numTilesOnY];
            int indexOfClosestRow = 0;

            for (int i = 0; i < MapState.numTilesOnY; i++)
            {
                if (MapRenderer.tileList[i][0] == null)
                {
                    tileValuesY[i] = 0;
                    continue;
                }

                tileValuesY[i] = Convert.ToInt32(Math.Floor(MapRenderer.tileList[i][0].tileY));
            }

            int yToInt = Convert.ToInt32(Math.Floor(y));

            for (int i = 0; i < tileValuesY.Length; i++)
            {
                if (yToInt < tileValuesY[i])
                {
                    tileValuesY[i] -= yToInt;
                }
                else if (yToInt > tileValuesY[i]) {
                    tileValuesY[i] = yToInt - tileValuesY[i];
                }

                // if the loop has finished(don't ask why): 
                if (i == tileValuesY.Length - 1)
                {
                    int hitherSmallestDigit = 0;
                    for (int j = 0; j < tileValuesY.Length; j++)
                    {
                        if (tileValuesY[j] < hitherSmallestDigit || hitherSmallestDigit == 0)
                        {
                            hitherSmallestDigit = tileValuesY[j];
                            indexOfClosestRow = j;
                        }
                    }
                }
            }
            int indexOfClosestTileInRow = 0;
            int[] tileValuesX = new int[MapState.numTilesOnX];

            for (int i = 0; i < MapState.numTilesOnX; i++)
            {
                if (MapRenderer.tileList[indexOfClosestRow][i] == null)
                {
                    tileValuesX[i] = 0;
                    continue;
                }
                tileValuesX[i] = Convert.ToInt32(Math.Floor(MapRenderer.tileList[indexOfClosestRow][i].tileX));
            }

            int xToInt = Convert.ToInt32(Math.Floor(x));

            for (int i = 0; i < tileValuesX.Length; i++)
            {
                if (xToInt < tileValuesX[i])
                {
                    tileValuesX[i] -= xToInt;
                }

                else if (xToInt > tileValuesX[i])
                {
                    tileValuesX[i] = xToInt - tileValuesX[i];
                }

                if (i == tileValuesX.Length - 1)
                {
                    int hitherSmallestDigit = 0;
                    for (int j = 0; j < tileValuesX.Length; j++)
                    {
                        if (tileValuesX[j] < hitherSmallestDigit || hitherSmallestDigit == 0)
                        {
                            hitherSmallestDigit = tileValuesX[j];
                            indexOfClosestTileInRow = j;
                        }
                    }
                }
            }
            int[] closestXY = new int[]
            {
                indexOfClosestTileInRow,
                indexOfClosestRow
            };
            return closestXY;
        }
    }
    public delegate void InitPos();
}