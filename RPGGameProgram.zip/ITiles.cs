



interface ITiles
{
    void TrackXY();
    void DefineTile();
}