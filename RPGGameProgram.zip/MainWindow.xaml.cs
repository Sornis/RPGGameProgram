﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.Threading;

namespace RPGGameProgram
{
    public partial class MainWindow : Window
    {

        DispatcherTimer gameTimer = new DispatcherTimer();
        CharacterState s = new CharacterState(2, true, true);
        CharacterAction a;
        MapState m;
        MoveIf moveState1;
        

        public MainWindow()
        {
            InitializeComponent();
            GameCanvas.Focus();
            gameTimer.Interval = TimeSpan.FromMilliseconds(50);
            gameTimer.Tick += GameplayLoop;
            gameTimer.Start();

            GameCanvas.Children.Add(s.rectangle);

            m = new MapState(10, 10);
            m.SetMapDimensions();
            m.SetMapPos();
            MapRenderer map = new MapRenderer();
            map.InitializeMap(GameCanvas);

            a = new CharacterAction(s);
            s.y = 210;

            moveState1 = new MoveIf(s.AtOuterBounds);

        }

        private void GameplayLoop(object sender, EventArgs e)
        {

            // player movement
            s.GetClosestTile();

            a.Move(moveState1);
            xLabel.Content = "X: " + s.GetClosestTile()[0];
            yLabel.Content = "Y: " + s.GetClosestTile()[1];


        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.W)
            {
                s.moveUp = true;
            }

            if (e.Key == Key.S)
            {
                s.moveDown = true;
            }

            if (e.Key == Key.A)
            {
                s.moveLeft = true;
            }

            if (e.Key == Key.D)
            {
                s.moveRight = true;
            }
        }

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                s.moveUp = false;
            }

            if (e.Key == Key.S)
            {
                s.moveDown = false;
            }

            if (e.Key == Key.A)
            {
                s.moveLeft = false;
            }

            if (e.Key == Key.D)
            {
                s.moveRight = false;
            }
        }
    }
}
