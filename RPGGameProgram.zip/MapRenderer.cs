using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.Threading;

namespace RPGGameProgram
{
    class MapRenderer
    {
        public Rectangle? tile;
        public double tileX;
        public double tileY;
        public bool isSolid;
        public SolidColorBrush colour = Brushes.Green;
        public static List<List<MapRenderer>>? tileList;

        public void InitializeMap(Canvas gameCanvas)
        {
            int topPlacement = 0;

            tileList = new List<List<MapRenderer>>(MapState.numTilesOnY);

            for (int i = 0; i < MapState.numTilesOnY; i++)
            {
                int leftPlacement = 0;
                tileList.Add(new List<MapRenderer>(MapState.numTilesOnX));
                for (int j = 0; j < MapState.numTilesOnX; j++)
                {
                    MapRenderer tileObj = new MapRenderer();
                    tileObj.SetTileXY(leftPlacement, topPlacement);
                    tileObj.DefineTile();
                    gameCanvas.Children.Add(tileObj.tile);

                    leftPlacement += MapState.TileWidth;
                    // [i] for # of rows, [j] for # of items in a row
                    tileList[i].Add(tileObj);
                }
                topPlacement += MapState.TileHeight;
            }
        }

        void SetTileXY(double leftPlacement, double topPlacement)
        {
            tileX = MapState.mapXLocation + leftPlacement;
            tileY = MapState.mapYLocation + topPlacement;
        }

        void DefineTile()
        {
            tile = new Rectangle();
            tile.Height = MapState.TileHeight;
            tile.Width = MapState.TileWidth;
            tile.Fill = colour;
            Canvas.SetLeft(tile, tileX);
            Canvas.SetTop(tile, tileY);
        }
    }
}