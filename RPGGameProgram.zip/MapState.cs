using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.Threading;

namespace RPGGameProgram
{
    class MapState
    {
        
        public const int TileHeight = 30;
        public const int TileWidth = 30;

        // these are set upon initializing the map
        // and used to initialize the 2d list which 
        // contains the tile objects
        public static int numTilesOnY;
        public static int numTilesOnX;

        // used to determine what the maps' outer bounds are
        public static double mapHeight;
        public static double mapWidth;

        // these are used to determine where on the canvas
        // to start drawing the map when it's initially drawn
        // may remove and return them as an array from SetMapPos()
        // instead
        public static double mapXLocation;
        public static double mapYLocation;

        

        public MapState(int numTilesOnY, int numTilesOnX)
        {
            MapState.numTilesOnY = numTilesOnY;
            MapState.numTilesOnX= numTilesOnX;
        }

        public void SetMapPos()
        {
            mapXLocation = (800 / 2) - (numTilesOnX * TileWidth / 2);
            mapYLocation = (500 / 2) - (numTilesOnY * TileHeight / 2);
        }

        public void SetMapDimensions()
        {
            mapWidth = numTilesOnX * TileWidth;
            mapHeight = numTilesOnY * TileHeight;
        }
    }
}